'use strict';
const statusNode=document.querySelector('#status');
const result=document.querySelector('#result');
const reload=document.querySelector('#reload');
const serviceList=document.querySelector('#services');
const slotList=document.querySelector('#slots');
const dates=new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Jakarta'});
function el(tag,text,className){const n=document.createElement(tag);n.textContent=text;if(className)n.className=className;return n;}
async function get(path){const response=await fetch(path);if(!response.ok)throw new Error('API belum siap.');return response.json();}
async function tryContract(slotId,button){
  button.disabled=true;result.textContent='Memeriksa respons kontrak…';
  try{
    const response=await fetch('/api/bookings',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':'demo-contract-'+slotId},body:JSON.stringify({slotId})});
    const body=await response.json();
    result.textContent=response.ok?'Respons berubah. Periksa implementasi tim dan bukti database sebelum menyimpulkan berhasil.':response.status+' · '+(body.error?.message || 'Operasi belum tersedia.');
  }catch{result.textContent='Server belum bisa dihubungi. Belum ada keberhasilan yang bisa dipastikan.';}
  finally{button.disabled=false;}
}
async function load(){
  reload.disabled=true;statusNode.textContent='Memuat layanan dan sesi…';
  try{
    const [services,slots]=await Promise.all([get('/api/services'),get('/api/slots')]);
    const names=new Map(services.data.map(s=>[s.id,s.name]));
    serviceList.replaceChildren(...services.data.map(s=>{const n=el('article','','service');n.append(el('span',s.id,'badge'),el('h3',s.name),el('p',s.description),el('p',s.durationMinutes+' menit · '+s.location));return n;}));
    slotList.replaceChildren(...slots.data.map(s=>{
      const n=el('article','','slot');const button=el('button','Coba kontrak booking (belum dibuat)');button.type='button';
      button.addEventListener('click',()=>tryContract(s.id,button));
      n.append(el('span',s.id+' · '+(s.status==='open'?'TERBUKA':'DITUTUP'),s.status==='open'?'badge':'badge closed'),el('h3',names.get(s.serviceId)||s.serviceId),el('p',dates.format(new Date(s.startsAt))+' WIB'),el('p',s.location),el('p','Sisa '+s.remaining+' dari '+s.capacity+' kursi'),button);return n;
    }));
    statusNode.textContent=slots.data.length+' sesi dari database demo. Tombol kontrak mengembalikan pesan fitur yang masih perlu dibangun.';
  }catch{
    serviceList.replaceChildren();slotList.replaceChildren();statusNode.textContent='Data belum bisa dimuat. Pastikan seed.py sudah dijalankan dan server.py masih aktif.';
  }finally{reload.disabled=false;}
}
reload.addEventListener('click',load);load();
