"""Buat database demo SlotKita. Jalankan sekali sebelum server.py."""
import argparse
import json
import sqlite3
from datetime import datetime, date, time, timedelta, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATABASE = BASE/'penyimpanan/database.db'
WIB = timezone(timedelta(hours=7))

def create_database(database=DATABASE, reset=False, today=None):
    database = Path(database)
    if database.exists():
        if not reset:
            raise ValueError('Database demo sudah ada. Langsung jalankan server.py. Untuk memulai ulang data demo, jalankan seed.py --reset.')
        database.unlink()
    data = json.loads((BASE.parent/'Bahan_Kerja/Data_Awal.json').read_text(encoding='utf-8'))
    anchor = today or datetime.now(WIB).date()
    database.parent.mkdir(parents=True,exist_ok=True)
    db = sqlite3.connect(database)
    try:
        db.executescript((BASE/'skema.sql').read_text(encoding='utf-8'))
        with db:
            db.executemany('INSERT INTO users VALUES (?,?,?,?)',[
                ('U-A','demo:user-a','User A','user'),
                ('U-B','demo:user-b','User B','user'),
                ('U-ADMIN','demo:admin','Admin Demo','admin')])
            services = {s['id']:s for s in data['services']}
            db.executemany('INSERT INTO services VALUES (?,?,?,?,?)',[
                (s['id'],s['name'],s['description'],s['location'],s['durationMinutes']) for s in data['services']])
            for slot in data['slots']:
                hour,minute=map(int,slot['startLocal'].split(':'))
                start=datetime.combine(anchor+timedelta(days=slot['dayOffset']),time(hour,minute),tzinfo=WIB)
                end=start+timedelta(minutes=services[slot['serviceId']]['durationMinutes'])
                utc=lambda value:value.astimezone(timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
                db.execute('INSERT INTO slots VALUES (?,?,?,?,?,?)',(
                    slot['id'],slot['serviceId'],utc(start),utc(end),slot['capacity'],slot['status']))
    except Exception:
        db.close()
        database.unlink(missing_ok=True)
        raise
    finally:
        db.close()
    return database

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reset',action='store_true',help='Kosongkan lalu buat ulang database demo lokal.')
    args=parser.parse_args()
    try:
        result=create_database(reset=args.reset)
        print('Database demo siap:',result)
        print('Jalankan: python server.py — lalu buka http://127.0.0.1:8080')
        print('Identitas seed adalah data contoh; login belum dibuat dan tidak ada password bawaan.')
    except (ValueError,OSError,sqlite3.Error) as error:
        parser.exit(1,str(error)+'\n')

if __name__=='__main__':main()
