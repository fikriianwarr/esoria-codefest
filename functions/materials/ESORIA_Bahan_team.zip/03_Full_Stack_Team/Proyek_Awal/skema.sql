PRAGMA foreign_keys = ON;

CREATE TABLE users (
 id TEXT PRIMARY KEY,
 auth_subject TEXT NOT NULL UNIQUE,
 display_name TEXT NOT NULL,
 role TEXT NOT NULL CHECK (role IN ('user','admin'))
);
CREATE TABLE services (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 description TEXT NOT NULL,
 location TEXT NOT NULL,
 duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0)
);
CREATE TABLE slots (
 id TEXT PRIMARY KEY,
 service_id TEXT NOT NULL REFERENCES services(id),
 starts_at TEXT NOT NULL,
 ends_at TEXT NOT NULL CHECK (ends_at > starts_at),
 capacity INTEGER NOT NULL CHECK (capacity BETWEEN 1 AND 20),
 status TEXT NOT NULL CHECK (status IN ('open','closed'))
);
CREATE TABLE bookings (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 slot_id TEXT NOT NULL REFERENCES slots(id),
 status TEXT NOT NULL CHECK (status IN ('confirmed','cancelled')),
 created_at TEXT NOT NULL,
 cancelled_at TEXT,
 CHECK ((status='confirmed' AND cancelled_at IS NULL) OR
        (status='cancelled' AND cancelled_at IS NOT NULL))
);
CREATE UNIQUE INDEX unique_active_user_slot ON bookings(user_id,slot_id)
 WHERE status='confirmed';
CREATE INDEX booking_slot_status ON bookings(slot_id,status);
CREATE TABLE idempotency (
 user_id TEXT NOT NULL REFERENCES users(id),
 operation TEXT NOT NULL,
 request_key TEXT NOT NULL,
 payload_hash TEXT NOT NULL,
 resource_id TEXT NOT NULL REFERENCES bookings(id),
 created_at TEXT NOT NULL,
 PRIMARY KEY (user_id,operation,request_key)
);
CREATE TABLE audit (
 id TEXT PRIMARY KEY,
 actor_id TEXT NOT NULL REFERENCES users(id),
 action TEXT NOT NULL,
 resource_id TEXT NOT NULL,
 occurred_at TEXT NOT NULL
);
-- Kamu masih perlu membangun transaksi booking/cancel/admin dan otorisasi.
-- Constraint di atas belum menjamin jumlah booking aktif <= capacity.
-- Semua timestamp ditulis dalam UTC ISO 8601 yang konsisten oleh server.
