"""Fondasi lokal SlotKita: baca layanan/sesi. Fitur lomba dikerjakan tim."""
import argparse
import json
import mimetypes
import sqlite3
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, unquote

BASE=Path(__file__).resolve().parent
WEB=(BASE/'web').resolve()
DATABASE=BASE/'penyimpanan/database.db'

def connect():
    db=sqlite3.connect('file:'+DATABASE.as_posix()+'?mode=ro',uri=True)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db

class Handler(BaseHTTPRequestHandler):
    def send_bytes(self,status,payload,content_type):
        self.send_response(status)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(payload)

    def send_json(self,status,value):
        self.send_bytes(status,json.dumps(value,ensure_ascii=False).encode('utf-8'),'application/json; charset=utf-8')

    def error_json(self,status,code,message):
        self.send_json(status,{'error':{'code':code,'message':message}})

    def do_GET(self):
        url=urlsplit(self.path)
        if url.path.startswith('/api/'):
            try:
                with closing(connect()) as db:
                    if url.path=='/api/health':
                        db.execute('SELECT count(*) FROM services').fetchone()
                        self.send_json(200,{'status':'ready','mode':'starter','database':'demo'})
                    elif url.path=='/api/services':
                        rows=db.execute('SELECT id,name,description,location,duration_minutes AS durationMinutes FROM services ORDER BY id').fetchall()
                        self.send_json(200,{'data':[dict(row) for row in rows]})
                    elif url.path=='/api/slots':
                        service=parse_qs(url.query).get('serviceId',[''])[0]
                        query='''SELECT s.id,s.service_id AS serviceId,s.starts_at AS startsAt,
                          s.ends_at AS endsAt,s.capacity,s.status,v.location,
                          s.capacity-(SELECT count(*) FROM bookings b
                            WHERE b.slot_id=s.id AND b.status='confirmed') AS remaining
                          FROM slots s JOIN services v ON v.id=s.service_id'''
                        params=()
                        if service:query+=' WHERE s.service_id=?';params=(service,)
                        rows=db.execute(query+' ORDER BY s.starts_at,s.id',params).fetchall()
                        self.send_json(200,{'data':[dict(row) for row in rows]})
                    else:self.error_json(404,'NOT_FOUND','Rute API ini belum tersedia pada fondasi awal.')
            except sqlite3.Error:
                self.error_json(503,'DATABASE_UNAVAILABLE','Database demo belum siap. Jalankan seed.py lalu coba lagi.')
            return
        # Hanya direktori web yang dilayani. Source, database, dan dokumen tidak dipublikasikan.
        try:
            path=(WEB/unquote(url.path).lstrip('/')).resolve()
        except (ValueError,OSError):
            self.error_json(404,'NOT_FOUND','Berkas tidak ditemukan.');return
        if not path.is_relative_to(WEB):
            self.error_json(404,'NOT_FOUND','Berkas tidak ditemukan.');return
        if path.is_dir():path=path/'index.html'
        if not path.is_file():
            self.error_json(404,'NOT_FOUND','Berkas tidak ditemukan.');return
        content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
        if content_type.startswith('text/') or content_type=='application/javascript':content_type+='; charset=utf-8'
        self.send_bytes(200,path.read_bytes(),content_type)

    def do_POST(self):
        self.error_json(501,'FEATURE_NOT_BUILT','Operasi ini masih tugas tim: bangun auth, izin, validasi, transaksi, dan penyimpanan sesuai brief. Belum ada booking yang dibuat.')

    def do_PATCH(self):self.do_POST()
    def do_DELETE(self):self.do_POST()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8080)
    args=parser.parse_args()
    if not 1<=args.port<=65535:parser.error('Port perlu berada pada rentang 1 sampai 65535.')
    if not DATABASE.is_file():parser.exit(1,'Database demo belum ada. Jalankan python seed.py terlebih dahulu.\n')
    with ThreadingHTTPServer(('127.0.0.1',args.port),Handler) as server:
        print(f'SlotKita siap di http://127.0.0.1:{args.port} — Ctrl+C untuk berhenti.')
        print('Server ini untuk fondasi lokal. Fitur booking/login/admin masih perlu dibangun tim.')
        try:server.serve_forever()
        except KeyboardInterrupt:pass

if __name__=='__main__':main()
