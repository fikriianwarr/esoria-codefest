// Fondasi awal: pemuatan data dan render kartu. Fitur lomba dikembangkan peserta.
'use strict';
const cards = document.querySelector('#cards');
const statusNode = document.querySelector('#status');
const count = document.querySelector('#jumlah');
const retry = document.querySelector('#retry');
const money = new Intl.NumberFormat('id-ID', {style:'currency',currency:'IDR',maximumFractionDigits:0});
const date = new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Jakarta'});
const labels = {available:'Tersedia',sold_out:'Kuota habis',cancelled:'Dibatalkan'};
let loading = false;
function element(tag, text, className) {
  const node = document.createElement(tag);
  node.textContent = text;
  if (className) node.className = className;
  return node;
}
function render(events) {
  const fragment = document.createDocumentFragment();
  for (const event of events) {
    const card = document.createElement('article');
    card.className = 'card';card.dataset.id=event.id;card.dataset.status=event.status;
    card.append(element('span',event.category,'tag'),element('h3',event.title),
      element('p',event.venue+' · '+event.city),element('p',date.format(new Date(event.startsAt))+' WIB'),
      element('p',event.description),element('p',event.price===0?'Gratis':money.format(event.price),'price'),
      element('p',labels[event.status] || event.status,'status-tag'));
    fragment.append(card);
  }
  cards.replaceChildren(fragment);
  count.textContent = events.length+' kegiatan';
}
async function load() {
  if (loading) return;
  loading=true;retry.hidden=true;statusNode.textContent='Memuat kegiatan…';
  try {
    const response=await fetch('../Bahan_Kerja/Data_Kegiatan.json');
    if (!response.ok) throw new Error('Data tidak tersedia.');
    const events=await response.json();
    if (!Array.isArray(events) || events.length!==12 || events.some(e=>!e.id || !e.title || !Number.isFinite(Date.parse(e.startsAt)))) throw new Error('Struktur data berbeda dari bahan lomba.');
    render(events);statusNode.textContent='Data siap. Lengkapi interaksinya sesuai brief.';
  } catch {
    cards.replaceChildren();count.textContent='Data belum termuat';
    statusNode.textContent='Kegiatan belum bisa dimuat. Jalankan server dari folder Website_Programming, lalu coba lagi.';retry.hidden=false;
  } finally {loading=false;}
}
retry.addEventListener('click',load);
load();
