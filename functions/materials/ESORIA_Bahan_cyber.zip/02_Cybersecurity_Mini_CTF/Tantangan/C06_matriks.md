# Matriks izin yang jadi acuan
- Anonymous: tidak boleh membaca booking atau menulis resource apa pun.
- User: boleh membaca services dan booking miliknya sendiri. Tidak boleh membaca booking orang lain atau mengubah slots.
- Admin: boleh membaca booking dan mengelola slots.

Cari hanya aturan effect=allow yang melanggar matriks ini. Urutkan ID aturan menaik, gabungkan dengan koma tanpa spasi, encode UTF-8 tanpa newline, hitung SHA-256, ambil 20 karakter hex pertama huruf kecil. Format akhirnya ESORIA{hasil_hash}. Nilai yang dibandingkan adalah izin aktual di aturan.json, bukan asumsi dari tampilan UI.
